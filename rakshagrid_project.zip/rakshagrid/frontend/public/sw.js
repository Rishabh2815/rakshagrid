// RakshaGrid service worker.
//
// Two jobs:
//   1. Cache the app shell so the PWA loads even with zero connectivity
//      (local LAN or fully offline).
//   2. Queue SOS requests made while offline in IndexedDB and flush them
//      the moment connectivity returns, via the Background Sync API
//      (with a fallback flush-on-load for browsers without Background
//      Sync support).
//
// This file is what makes the "works when the internet doesn't" claim in
// the design doc an actual property of the shipped app, not a slide.

const CACHE_NAME = "rakshagrid-shell-v1";
const APP_SHELL = ["/", "/index.html", "/manifest.json"];
const SOS_QUEUE_DB = "rakshagrid-sos-queue";
const SOS_QUEUE_STORE = "pending";

self.addEventListener("install", (event) => {
  event.waitUntil(
    caches.open(CACHE_NAME).then((cache) => cache.addAll(APP_SHELL))
  );
  self.skipWaiting();
});

self.addEventListener("activate", (event) => {
  event.waitUntil(
    caches.keys().then((keys) =>
      Promise.all(
        keys
          .filter((key) => key !== CACHE_NAME)
          .map((key) => caches.delete(key))
      )
    )
  );
  self.clients.claim();
});

// Network-first for API calls (fresh data matters more than cached data
// for a safety app), cache-first for the app shell (so the UI itself
// always loads instantly, online or not).
self.addEventListener("fetch", (event) => {
  const url = new URL(event.request.url);

  if (url.pathname.startsWith("/v1/")) {
    event.respondWith(
      fetch(event.request).catch(() => {
        // Offline API call: if this was an SOS POST, queue it instead of
        // failing silently — see handleOfflineSOS below.
        if (event.request.method === "POST" && url.pathname === "/v1/sos") {
          return handleOfflineSOS(event.request);
        }
        return new Response(
          JSON.stringify({ error: "offline — request could not be completed" }),
          { status: 503, headers: { "Content-Type": "application/json" } }
        );
      })
    );
    return;
  }

  event.respondWith(
    caches.match(event.request).then((cached) => cached || fetch(event.request))
  );
});

async function handleOfflineSOS(request) {
  const body = await request.clone().json();
  await queueSOS(body, request.headers.get("Authorization"));

  // Register a Background Sync so the queue flushes automatically once
  // connectivity returns, without requiring the user to reopen the app.
  if ("sync" in self.registration) {
    try {
      await self.registration.sync.register("flush-sos-queue");
    } catch (e) {
      // Background Sync unsupported/denied — the app's own reconnect
      // listener (see src/api.js) acts as the fallback flush trigger.
    }
  }

  return new Response(
    JSON.stringify({
      queued: true,
      message: "No connection — SOS saved locally and will be sent the moment connectivity returns.",
    }),
    { status: 202, headers: { "Content-Type": "application/json" } }
  );
}

self.addEventListener("sync", (event) => {
  if (event.tag === "flush-sos-queue") {
    event.waitUntil(flushQueue());
  }
});

async function flushQueue() {
  const db = await openQueueDB();
  const tx = db.transaction(SOS_QUEUE_STORE, "readonly");
  const all = await promisifyRequest(tx.objectStore(SOS_QUEUE_STORE).getAll());

  for (const item of all) {
    try {
      const res = await fetch("/v1/sos", {
        method: "POST",
        headers: { "Content-Type": "application/json", Authorization: item.auth },
        body: JSON.stringify(item.body),
      });
      if (res.ok) {
        const delTx = db.transaction(SOS_QUEUE_STORE, "readwrite");
        delTx.objectStore(SOS_QUEUE_STORE).delete(item.id);
      }
    } catch (e) {
      // Still offline — leave it queued, will retry on next sync event.
      break;
    }
  }
}

function queueSOS(body, auth) {
  return openQueueDB().then((db) => {
    const tx = db.transaction(SOS_QUEUE_STORE, "readwrite");
    tx.objectStore(SOS_QUEUE_STORE).add({
      body,
      auth,
      queuedAt: Date.now(),
    });
    return promisifyRequest(tx);
  });
}

function openQueueDB() {
  return new Promise((resolve, reject) => {
    const req = indexedDB.open(SOS_QUEUE_DB, 1);
    req.onupgradeneeded = () => {
      req.result.createObjectStore(SOS_QUEUE_STORE, { keyPath: "id", autoIncrement: true });
    };
    req.onsuccess = () => resolve(req.result);
    req.onerror = () => reject(req.error);
  });
}

function promisifyRequest(request) {
  return new Promise((resolve, reject) => {
    request.oncomplete = request.onsuccess = () => resolve(request.result);
    request.onerror = request.onabort = () => reject(request.error);
  });
}
