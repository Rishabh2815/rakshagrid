import React, { useEffect, useState } from "react";
import { api, getToken, setToken, clearToken } from "./api.js";
import LoginForm from "./pages/LoginForm.jsx";
import SOSButton from "./pages/SOSButton.jsx";
import ResponderDashboard from "./pages/ResponderDashboard.jsx";
import AdminDashboard from "./pages/AdminDashboard.jsx";

// Decodes the JWT payload client-side purely to read the role for view
// routing. This is NOT a trust boundary — every API call is still
// authorized server-side by auth.Middleware; this is UI convenience only.
function decodeRole(token) {
  try {
    const payload = JSON.parse(atob(token.split(".")[1]));
    return payload.role;
  } catch {
    return null;
  }
}

export default function App() {
  const [authed, setAuthed] = useState(!!getToken());
  const [role, setRole] = useState(getToken() ? decodeRole(getToken()) : null);
  const [online, setOnline] = useState(navigator.onLine);

  useEffect(() => {
    const goOnline = () => setOnline(true);
    const goOffline = () => setOnline(false);
    window.addEventListener("online", goOnline);
    window.addEventListener("offline", goOffline);
    return () => {
      window.removeEventListener("online", goOnline);
      window.removeEventListener("offline", goOffline);
    };
  }, []);

  function handleLoggedIn(token) {
    setToken(token);
    setAuthed(true);
    setRole(decodeRole(token));
  }

  function handleLogout() {
    clearToken();
    setAuthed(false);
    setRole(null);
  }

  return (
    <div style={{ fontFamily: "system-ui, sans-serif", maxWidth: 480, margin: "0 auto", padding: 16 }}>
      <header style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 16 }}>
        <h1 style={{ fontSize: 20, color: "#5A3A24" }}>RakshaGrid</h1>
        <span
          style={{
            fontSize: 12,
            padding: "2px 8px",
            borderRadius: 12,
            background: online ? "#e6f4ea" : "#fdecea",
            color: online ? "#1e7e34" : "#a02b2b",
          }}
        >
          {online ? "Online" : "Offline — SOS still works"}
        </span>
      </header>

      {!authed && <LoginForm onLoggedIn={handleLoggedIn} />}

      {authed && role === "student" && <SOSButton onLogout={handleLogout} />}
      {authed && role === "staff" && <SOSButton onLogout={handleLogout} />}
      {authed && (role === "warden" || role === "security" || role === "volunteer") && (
        <ResponderDashboard onLogout={handleLogout} />
      )}
      {authed && role === "admin" && <AdminDashboard onLogout={handleLogout} />}
      {authed && !role && (
        <div>
          <p>Signed in, but role could not be determined.</p>
          <button onClick={handleLogout}>Log out</button>
        </div>
      )}
    </div>
  );
}
