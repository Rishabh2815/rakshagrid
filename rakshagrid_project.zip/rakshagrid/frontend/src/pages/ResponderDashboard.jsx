import React, { useEffect, useRef, useState } from "react";
import { api, openStream } from "../api.js";

const HEARTBEAT_INTERVAL_MS = 15000; // stays well inside the 45s presence TTL on the backend

export default function ResponderDashboard({ onLogout }) {
  const [available, setAvailable] = useState(false);
  const [alerts, setAlerts] = useState([]); // incoming SOS alerts not yet acted on
  const [activeIncident, setActiveIncident] = useState(null);
  const heartbeatRef = useRef(null);
  const closeStreamRef = useRef(null);

  useEffect(() => {
    closeStreamRef.current = openStream(handleStreamMessage);
    return () => {
      closeStreamRef.current && closeStreamRef.current();
      stopHeartbeat();
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  function handleStreamMessage(msg) {
    if (msg.type === "sos_alert") {
      setAlerts((prev) => [msg.payload, ...prev]);
      // Nudge with sound/vibration where supported — best-effort, never blocks.
      if (navigator.vibrate) navigator.vibrate([200, 100, 200]);
    }
  }

  function startHeartbeat() {
    if (!("geolocation" in navigator)) return;

    const send = () => {
      navigator.geolocation.getCurrentPosition(
        (pos) => api.responderHeartbeat(pos.coords.latitude, pos.coords.longitude).catch(() => {}),
        () => {},
        { enableHighAccuracy: true, timeout: 8000 }
      );
    };

    send();
    heartbeatRef.current = setInterval(send, HEARTBEAT_INTERVAL_MS);
  }

  function stopHeartbeat() {
    if (heartbeatRef.current) clearInterval(heartbeatRef.current);
    heartbeatRef.current = null;
  }

  async function toggleAvailability() {
    if (available) {
      await api.responderOffline().catch(() => {});
      stopHeartbeat();
      setAvailable(false);
    } else {
      startHeartbeat();
      setAvailable(true);
    }
  }

  async function acceptAlert(sosAlert) {
    try {
      await api.ackIncident(sosAlert.incident_id);
      setActiveIncident(sosAlert);
      setAlerts((prev) => prev.filter((a) => a.incident_id !== sosAlert.incident_id));
    } catch (err) {
      window.alert("Failed to accept: " + err.message); // eslint-disable-line no-alert
    }
  }

  async function resolveActive() {
    if (!activeIncident) return;
    try {
      await api.resolveIncident(activeIncident.incident_id, "resolved by responder");
      setActiveIncident(null);
    } catch (err) {
      console.error(err);
    }
  }

  return (
    <div style={{ display: "flex", flexDirection: "column", gap: 16 }}>
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
        <span style={{ fontSize: 14, fontWeight: 600 }}>
          {available ? "You are available" : "You are offline"}
        </span>
        <button
          onClick={toggleAvailability}
          style={{
            padding: "6px 14px",
            borderRadius: 16,
            border: "none",
            background: available ? "#1e7e34" : "#888",
            color: "#fff",
            fontSize: 12,
            cursor: "pointer",
          }}
        >
          {available ? "Go offline" : "Go available"}
        </button>
      </div>

      {activeIncident && (
        <div style={{ padding: 12, borderRadius: 8, background: "#fdecea", border: "1px solid #D14520" }}>
          <p style={{ fontSize: 13, fontWeight: 600 }}>Active incident: {activeIncident.type}</p>
          <p style={{ fontSize: 12, color: "#666" }}>
            Location: {activeIncident.lat?.toFixed(5)}, {activeIncident.lng?.toFixed(5)}
          </p>
          <button
            onClick={resolveActive}
            style={{ marginTop: 8, padding: "6px 12px", borderRadius: 6, border: "none", background: "#1e7e34", color: "#fff", cursor: "pointer" }}
          >
            Mark resolved
          </button>
        </div>
      )}

      <div>
        <h3 style={{ fontSize: 14, marginBottom: 8 }}>Incoming alerts</h3>
        {alerts.length === 0 && <p style={{ fontSize: 12, color: "#999" }}>No alerts right now.</p>}
        {alerts.map((a) => (
          <div
            key={a.incident_id}
            style={{ padding: 10, borderRadius: 8, border: "1px solid #D14520", marginBottom: 8 }}
          >
            <p style={{ fontSize: 13, fontWeight: 600 }}>{a.type} — SOS</p>
            <p style={{ fontSize: 11, color: "#666" }}>
              {a.lat?.toFixed(5)}, {a.lng?.toFixed(5)}
            </p>
            <button
              onClick={() => acceptAlert(a)}
              style={{ marginTop: 6, padding: "6px 12px", borderRadius: 6, border: "none", background: "#D14520", color: "#fff", cursor: "pointer" }}
            >
              Accept
            </button>
          </div>
        ))}
      </div>

      <button onClick={onLogout} style={{ fontSize: 12, background: "none", border: "none", color: "#888", cursor: "pointer" }}>
        Log out
      </button>
    </div>
  );
}
