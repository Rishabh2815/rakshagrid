import React, { useEffect, useState } from "react";
import { api } from "../api.js";

export default function AdminDashboard({ onLogout }) {
  const [report, setReport] = useState(null);
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    api
      .complianceReport()
      .then(({ data }) => setReport(data))
      .catch((err) => setError(err.message))
      .finally(() => setLoading(false));
  }, []);

  return (
    <div style={{ display: "flex", flexDirection: "column", gap: 16 }}>
      <h2 style={{ fontSize: 16 }}>Compliance report — trailing 30 days</h2>

      {loading && <p style={{ fontSize: 13, color: "#999" }}>Loading...</p>}
      {error && <p style={{ fontSize: 13, color: "#a02b2b" }}>{error}</p>}

      {report && (
        <div style={{ display: "flex", flexDirection: "column", gap: 12 }}>
          <div style={statGrid}>
            <Stat label="Total incidents" value={report.total_incidents} />
            <Stat label="Resolved" value={report.resolved_incidents} />
            <Stat
              label="Avg response time"
              value={
                report.avg_response_seconds
                  ? `${Math.round(report.avg_response_seconds)}s`
                  : "—"
              }
            />
          </div>

          <div>
            <h3 style={{ fontSize: 13, marginBottom: 6 }}>By incident type</h3>
            {Object.keys(report.incidents_by_type || {}).length === 0 && (
              <p style={{ fontSize: 12, color: "#999" }}>No incidents recorded in this period.</p>
            )}
            {Object.entries(report.incidents_by_type || {}).map(([type, count]) => (
              <div key={type} style={{ display: "flex", justifyContent: "space-between", fontSize: 13, padding: "4px 0", borderBottom: "1px solid #eee" }}>
                <span>{type}</span>
                <span>{count}</span>
              </div>
            ))}
          </div>

          <p style={{ fontSize: 11, color: "#999" }}>
            This report is generated from the append-only incident audit log — see the system design doc,
            §5.3, for how this becomes a paid compliance-reporting product.
          </p>
        </div>
      )}

      <button onClick={onLogout} style={{ fontSize: 12, background: "none", border: "none", color: "#888", cursor: "pointer" }}>
        Log out
      </button>
    </div>
  );
}

function Stat({ label, value }) {
  return (
    <div style={{ padding: 10, borderRadius: 8, background: "#F4EFE6", textAlign: "center" }}>
      <div style={{ fontSize: 20, fontWeight: 700, color: "#5A3A24" }}>{value}</div>
      <div style={{ fontSize: 11, color: "#666" }}>{label}</div>
    </div>
  );
}

const statGrid = { display: "grid", gridTemplateColumns: "repeat(3, 1fr)", gap: 8 };
