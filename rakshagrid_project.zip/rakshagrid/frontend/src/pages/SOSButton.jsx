import React, { useEffect, useRef, useState } from "react";
import { api, openStream } from "../api.js";

const INCIDENT_TYPES = [
  { value: "safety", label: "Safety / harassment" },
  { value: "medical", label: "Medical emergency" },
  { value: "fire", label: "Fire" },
  { value: "security", label: "Security breach" },
];

export default function SOSButton({ onLogout }) {
  const [type, setType] = useState("safety");
  const [status, setStatus] = useState("idle"); // idle | locating | sending | queued | matched | acked | resolved | error
  const [incidentId, setIncidentId] = useState(null);
  const [statusText, setStatusText] = useState("");
  const closeStreamRef = useRef(null);

  useEffect(() => {
    closeStreamRef.current = openStream(handleStreamMessage);
    return () => closeStreamRef.current && closeStreamRef.current();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  function handleStreamMessage(msg) {
    if (msg.type === "status_update") {
      setStatus("acked");
      setStatusText("A responder has accepted your SOS and is on the way.");
    } else if (msg.type === "incident_resolved") {
      setStatus("resolved");
      setStatusText("This incident has been marked resolved.");
    }
  }

  function raiseSOS() {
    setStatus("locating");
    setStatusText("Getting your location...");

    if (!("geolocation" in navigator)) {
      setStatus("error");
      setStatusText("Location services are not available on this device.");
      return;
    }

    navigator.geolocation.getCurrentPosition(
      async (pos) => {
        setStatus("sending");
        setStatusText("Sending SOS...");
        try {
          const { data, status: httpStatus } = await api.raiseSOS(
            type,
            pos.coords.latitude,
            pos.coords.longitude
          );
          if (httpStatus === 202 && data.queued) {
            setStatus("queued");
            setStatusText(data.message);
          } else {
            setIncidentId(data.incident_id);
            setStatus(data.matched_responders?.length ? "matched" : "sending");
            setStatusText(
              data.matched_responders?.length
                ? `Alert sent to ${data.matched_responders.length} nearby responder(s). Help is being dispatched.`
                : "SOS recorded. Searching for an available responder near you..."
            );
          }
        } catch (err) {
          setStatus("error");
          setStatusText(err.message);
        }
      },
      () => {
        setStatus("error");
        setStatusText("Could not get your location. Please enable location access and try again.");
      },
      { enableHighAccuracy: true, timeout: 10000 }
    );
  }

  const isActive = ["locating", "sending", "queued", "matched", "acked"].includes(status);

  return (
    <div style={{ display: "flex", flexDirection: "column", gap: 16, alignItems: "center" }}>
      {!isActive && (
        <>
          <label style={{ width: "100%", fontSize: 13 }}>
            Incident type
            <select
              value={type}
              onChange={(e) => setType(e.target.value)}
              style={{ width: "100%", padding: 8, marginTop: 4, borderRadius: 6, border: "1px solid #ccc" }}
            >
              {INCIDENT_TYPES.map((t) => (
                <option key={t.value} value={t.value}>
                  {t.label}
                </option>
              ))}
            </select>
          </label>

          <button
            onClick={raiseSOS}
            style={{
              width: 180,
              height: 180,
              borderRadius: "50%",
              border: "none",
              background: "#D14520",
              color: "#fff",
              fontSize: 22,
              fontWeight: 700,
              cursor: "pointer",
              boxShadow: "0 4px 14px rgba(209,69,32,0.4)",
            }}
          >
            SOS
          </button>
          <p style={{ fontSize: 12, color: "#666", textAlign: "center" }}>
            One tap alerts the nearest verified responder with your live location.
            Works even without internet on campus Wi-Fi/LAN.
          </p>
        </>
      )}

      {isActive && (
        <div style={{ textAlign: "center", padding: 24 }}>
          <div
            style={{
              width: 80,
              height: 80,
              borderRadius: "50%",
              background: status === "acked" ? "#1e7e34" : "#D14520",
              margin: "0 auto 16px",
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
              color: "#fff",
              fontWeight: 700,
            }}
          >
            {status === "acked" ? "OK" : "SOS"}
          </div>
          <p style={{ fontSize: 15, fontWeight: 600 }}>{statusText}</p>
          {incidentId && <p style={{ fontSize: 11, color: "#999" }}>Incident ID: {incidentId}</p>}
        </div>
      )}

      {status === "resolved" && (
        <button onClick={() => setStatus("idle")} style={{ fontSize: 13 }}>
          Start over
        </button>
      )}

      <button onClick={onLogout} style={{ fontSize: 12, background: "none", border: "none", color: "#888", cursor: "pointer" }}>
        Log out
      </button>
    </div>
  );
}
