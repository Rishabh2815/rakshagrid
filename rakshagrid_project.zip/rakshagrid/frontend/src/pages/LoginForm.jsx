import React, { useState } from "react";
import { api } from "../api.js";

export default function LoginForm({ onLoggedIn }) {
  const [mode, setMode] = useState("login"); // "login" | "register"
  const [tenantId, setTenantId] = useState("");
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [role, setRole] = useState("student");
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);

  async function handleSubmit(e) {
    e.preventDefault();
    setError("");
    setBusy(true);
    try {
      const { data } = mode === "login"
        ? await api.login(tenantId, email, password)
        : await api.register(tenantId, name, email, password, role);
      onLoggedIn(data.token);
    } catch (err) {
      setError(err.message);
    } finally {
      setBusy(false);
    }
  }

  return (
    <form onSubmit={handleSubmit} style={{ display: "flex", flexDirection: "column", gap: 10 }}>
      <h2 style={{ fontSize: 16 }}>{mode === "login" ? "Sign in" : "Register"}</h2>

      <label style={labelStyle}>
        Tenant ID (your campus)
        <input value={tenantId} onChange={(e) => setTenantId(e.target.value)} required style={inputStyle} />
      </label>

      {mode === "register" && (
        <label style={labelStyle}>
          Name
          <input value={name} onChange={(e) => setName(e.target.value)} required style={inputStyle} />
        </label>
      )}

      <label style={labelStyle}>
        Email
        <input type="email" value={email} onChange={(e) => setEmail(e.target.value)} required style={inputStyle} />
      </label>

      <label style={labelStyle}>
        Password
        <input
          type="password"
          value={password}
          onChange={(e) => setPassword(e.target.value)}
          required
          minLength={8}
          style={inputStyle}
        />
      </label>

      {mode === "register" && (
        <label style={labelStyle}>
          Role
          <select value={role} onChange={(e) => setRole(e.target.value)} style={inputStyle}>
            <option value="student">Student</option>
            <option value="staff">Staff</option>
            <option value="warden">Responder — Warden</option>
            <option value="security">Responder — Security</option>
            <option value="volunteer">Responder — Volunteer</option>
            <option value="admin">Institute Admin</option>
          </select>
        </label>
      )}

      {error && <p style={{ color: "#a02b2b", fontSize: 13 }}>{error}</p>}

      <button type="submit" disabled={busy} style={buttonStyle}>
        {busy ? "Please wait..." : mode === "login" ? "Sign in" : "Register"}
      </button>

      <button
        type="button"
        onClick={() => setMode(mode === "login" ? "register" : "login")}
        style={{ background: "none", border: "none", color: "#5A3A24", cursor: "pointer", fontSize: 13 }}
      >
        {mode === "login" ? "New here? Register instead" : "Already registered? Sign in instead"}
      </button>
    </form>
  );
}

const labelStyle = { display: "flex", flexDirection: "column", fontSize: 13, gap: 4 };
const inputStyle = { padding: 8, fontSize: 14, borderRadius: 6, border: "1px solid #ccc" };
const buttonStyle = {
  padding: 10,
  fontSize: 14,
  fontWeight: 600,
  borderRadius: 6,
  border: "none",
  background: "#5A3A24",
  color: "#fff",
  cursor: "pointer",
};
