// Thin API client. Every call goes through /v1 (proxied to the Go
// backend in dev — see vite.config.js). Kept dependency-free on purpose:
// no axios, just fetch — one less thing to explain in a hackathon Q&A.

const TOKEN_KEY = "rakshagrid_token";

export function getToken() {
  return localStorage.getItem(TOKEN_KEY);
}

export function setToken(token) {
  localStorage.setItem(TOKEN_KEY, token);
}

export function clearToken() {
  localStorage.removeItem(TOKEN_KEY);
}

async function request(path, options = {}) {
  const token = getToken();
  const headers = {
    "Content-Type": "application/json",
    ...(token ? { Authorization: `Bearer ${token}` } : {}),
    ...options.headers,
  };

  const res = await fetch(path, { ...options, headers });
  const data = await res.json().catch(() => ({}));

  if (!res.ok && res.status !== 202) {
    // 202 = queued offline by the service worker, not a real failure.
    throw new Error(data.error || `Request failed: ${res.status}`);
  }
  return { data, status: res.status };
}

export const api = {
  createTenant: (name, region) =>
    request("/v1/tenants", { method: "POST", body: JSON.stringify({ name, region }) }),

  register: (tenantId, name, email, password, role) =>
    request("/v1/auth/register", {
      method: "POST",
      body: JSON.stringify({ tenant_id: tenantId, name, email, password, role }),
    }),

  login: (tenantId, email, password) =>
    request("/v1/auth/login", {
      method: "POST",
      body: JSON.stringify({ tenant_id: tenantId, email, password }),
    }),

  raiseSOS: (type, lat, lng) =>
    request("/v1/sos", { method: "POST", body: JSON.stringify({ type, lat, lng }) }),

  ackIncident: (id) => request(`/v1/incidents/${id}/ack`, { method: "POST" }),

  resolveIncident: (id, detail) =>
    request(`/v1/incidents/${id}/resolve`, { method: "POST", body: JSON.stringify({ detail }) }),

  responderHeartbeat: (lat, lng) =>
    request("/v1/responders/heartbeat", { method: "POST", body: JSON.stringify({ lat, lng }) }),

  responderOffline: () => request("/v1/responders/offline", { method: "POST" }),

  complianceReport: () => request("/v1/admin/compliance-report"),

  incidentTimeline: (id) => request(`/v1/admin/incidents/${id}/timeline`),
};

// openStream opens the realtime WebSocket channel and returns the raw
// WebSocket so callers can attach onmessage handlers. Reconnects with
// simple backoff — a dropped connection (e.g. moving between Wi-Fi
// access points) should not require a manual page reload.
export function openStream(onMessage) {
  let socket;
  let attempt = 0;

  function connect() {
    const token = getToken();
    if (!token) return;

    const protocol = window.location.protocol === "https:" ? "wss:" : "ws:";
    socket = new WebSocket(`${protocol}//${window.location.host}/v1/stream`, [], {
      headers: { Authorization: `Bearer ${token}` },
    });

    // Browsers don't support custom headers on WebSocket handshakes, so in
    // production this token should be passed as a query param or via a
    // short-lived cookie set at login — flagged in the README as a
    // pre-production hardening item.

    socket.onopen = () => {
      attempt = 0;
    };
    socket.onmessage = (event) => {
      try {
        onMessage(JSON.parse(event.data));
      } catch (e) {
        console.error("Failed to parse stream message:", e);
      }
    };
    socket.onclose = () => {
      attempt += 1;
      const delay = Math.min(1000 * 2 ** attempt, 30000);
      setTimeout(connect, delay);
    };
  }

  connect();
  return () => socket && socket.close();
}
