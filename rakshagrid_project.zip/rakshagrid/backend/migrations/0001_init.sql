-- RakshaGrid initial schema.
-- Design notes:
--   * tenant_id is on every table (shared-schema multi-tenancy for the
--     pilot stage). Large tenants get promoted to an isolated schema/DB
--     later — see docs/system-design §5.
--   * incident_events is append-only by convention: the application layer
--     never issues UPDATE/DELETE against it. A future hardening step is a
--     DB trigger that rejects them outright.

CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

CREATE TABLE tenants (
    id          UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    name        TEXT NOT NULL,
    region      TEXT NOT NULL DEFAULT 'ap-south-1',
    plan_tier   TEXT NOT NULL DEFAULT 'trial',
    created_at  TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE users (
    id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    tenant_id       UUID NOT NULL REFERENCES tenants(id),
    name            TEXT NOT NULL,
    email           TEXT NOT NULL,
    password_hash   TEXT NOT NULL,
    role            TEXT NOT NULL DEFAULT 'student',
    verified        BOOLEAN NOT NULL DEFAULT false,
    created_at      TIMESTAMPTZ NOT NULL DEFAULT now(),
    UNIQUE (tenant_id, email)
);

CREATE TABLE responders (
    id                    UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    tenant_id             UUID NOT NULL REFERENCES tenants(id),
    user_id               UUID NOT NULL REFERENCES users(id),
    responder_type        TEXT NOT NULL,
    verification_status   TEXT NOT NULL DEFAULT 'pending',
    created_at            TIMESTAMPTZ NOT NULL DEFAULT now(),
    UNIQUE (tenant_id, user_id)
);

CREATE TABLE incidents (
    id            UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    tenant_id     UUID NOT NULL REFERENCES tenants(id),
    raised_by     UUID NOT NULL REFERENCES users(id),
    type          TEXT NOT NULL,
    lat           DOUBLE PRECISION NOT NULL,
    lng           DOUBLE PRECISION NOT NULL,
    status        TEXT NOT NULL DEFAULT 'raised',
    responder_id  UUID REFERENCES responders(id),
    created_at    TIMESTAMPTZ NOT NULL DEFAULT now(),
    resolved_at   TIMESTAMPTZ
);

CREATE INDEX idx_incidents_tenant_status ON incidents (tenant_id, status);
CREATE INDEX idx_incidents_tenant_created ON incidents (tenant_id, created_at DESC);

-- Append-only audit trail. This table is the compliance backbone
-- referenced throughout the design doc — never update or delete rows.
CREATE TABLE incident_events (
    id            UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    incident_id   UUID NOT NULL REFERENCES incidents(id),
    event_type    TEXT NOT NULL,
    -- NULL actor_id = system-generated event (e.g. auto-escalation sweeper),
    -- not a human action. Every human-triggered event still carries a real
    -- user id here, preserving the accountability guarantee.
    actor_id      UUID REFERENCES users(id),
    detail        TEXT,
    timestamp     TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX idx_incident_events_incident ON incident_events (incident_id, timestamp);
