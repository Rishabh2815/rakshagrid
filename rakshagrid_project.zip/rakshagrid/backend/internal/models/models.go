// Package models defines the core domain entities shared across every
// service in the modular monolith. Keeping these in one package (rather
// than each service defining its own) is a deliberate monolith-stage
// choice — see docs/system-design for when this gets split.
package models

import "time"

type Role string

const (
	RoleStudent Role = "student"
	RoleStaff   Role = "staff"
	RoleAdmin   Role = "admin"
)

type ResponderType string

const (
	ResponderWarden      ResponderType = "warden"
	ResponderSecurity    ResponderType = "security"
	ResponderVolunteer   ResponderType = "volunteer"
)

type ResponderStatus string

const (
	ResponderAvailable ResponderStatus = "available"
	ResponderBusy       ResponderStatus = "busy"
	ResponderOffline    ResponderStatus = "offline"
)

type IncidentStatus string

const (
	IncidentRaised    IncidentStatus = "raised"
	IncidentMatched   IncidentStatus = "matched"
	IncidentAcked     IncidentStatus = "acked"
	IncidentEscalated IncidentStatus = "escalated"
	IncidentResolved  IncidentStatus = "resolved"
)

type IncidentType string

const (
	IncidentSafety  IncidentType = "safety"
	IncidentMedical IncidentType = "medical"
	IncidentFire    IncidentType = "fire"
	IncidentSecurity IncidentType = "security"
)

// Tenant represents one onboarded institute/campus.
type Tenant struct {
	ID        string    `json:"id"`
	Name      string    `json:"name"`
	Region    string    `json:"region"`
	PlanTier  string    `json:"plan_tier"`
	CreatedAt time.Time `json:"created_at"`
}

// User represents any verified person in a tenant — student, staff, or admin.
type User struct {
	ID           string    `json:"id"`
	TenantID     string    `json:"tenant_id"`
	Name         string    `json:"name"`
	Email        string    `json:"email"`
	PasswordHash string    `json:"-"`
	Role         Role      `json:"role"`
	Verified     bool      `json:"verified"`
	CreatedAt    time.Time `json:"created_at"`
}

// Responder is a User with an additional responder profile.
type Responder struct {
	ID                 string          `json:"id"`
	TenantID           string          `json:"tenant_id"`
	UserID             string          `json:"user_id"`
	ResponderType      ResponderType   `json:"responder_type"`
	VerificationStatus string          `json:"verification_status"`
	CreatedAt          time.Time       `json:"created_at"`
}

// ResponderPresence is the live, ephemeral location/status record for a
// responder. This is intentionally NOT persisted to Postgres — it lives in
// Redis as a geospatial member plus a short-TTL status hash, since presence
// is high-write, low-durability-requirement data.
type ResponderPresence struct {
	ResponderID string          `json:"responder_id"`
	Lat         float64         `json:"lat"`
	Lng         float64         `json:"lng"`
	Status      ResponderStatus `json:"status"`
	LastSeen    time.Time       `json:"last_seen"`
}

// Incident is one raised SOS and its full lifecycle.
type Incident struct {
	ID         string         `json:"id"`
	TenantID   string         `json:"tenant_id"`
	RaisedBy   string         `json:"raised_by"`
	Type       IncidentType   `json:"type"`
	Lat        float64        `json:"lat"`
	Lng        float64        `json:"lng"`
	Status     IncidentStatus `json:"status"`
	ResponderID *string       `json:"responder_id,omitempty"`
	CreatedAt  time.Time      `json:"created_at"`
	ResolvedAt *time.Time     `json:"resolved_at,omitempty"`
}

// IncidentEvent is one append-only entry in an incident's audit trail.
// Never updated or deleted — this table is the compliance backbone.
type IncidentEvent struct {
	ID         string    `json:"id"`
	IncidentID string    `json:"incident_id"`
	EventType  string    `json:"event_type"`
	ActorID    string    `json:"actor_id"`
	Timestamp  time.Time `json:"timestamp"`
	Detail     string    `json:"detail,omitempty"`
}
