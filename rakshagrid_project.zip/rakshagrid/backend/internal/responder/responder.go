// Package responder manages live responder presence: location and
// availability. This is deliberately NOT backed by Postgres — presence
// is high-frequency, low-durability-requirement data, so it lives
// entirely in Redis using a geospatial sorted set (one per tenant) plus
// a short-TTL status key per responder. If Redis restarts, responders
// simply re-heartbeat within seconds; nothing of compliance value is lost
// (that lives in the Postgres-backed audit package instead).
package responder

import (
	"context"
	"fmt"
	"time"

	"github.com/redis/go-redis/v9"

	"github.com/rishabhjha/rakshagrid/internal/models"
)

const presenceTTL = 45 * time.Second // responder considered offline if no heartbeat within this window

type Registry struct {
	rdb *redis.Client
}

func NewRegistry(rdb *redis.Client) *Registry {
	return &Registry{rdb: rdb}
}

func geoKey(tenantID string) string {
	return fmt.Sprintf("presence:geo:%s", tenantID)
}

func statusKey(tenantID, responderID string) string {
	return fmt.Sprintf("presence:status:%s:%s", tenantID, responderID)
}

// Heartbeat records (or refreshes) a responder's live location and
// availability. Called periodically by the responder's client app —
// typically every 15-20s, well inside presenceTTL.
func (reg *Registry) Heartbeat(ctx context.Context, tenantID string, p models.ResponderPresence) error {
	pipe := reg.rdb.TxPipeline()

	pipe.GeoAdd(ctx, geoKey(tenantID), &redis.GeoLocation{
		Name:      p.ResponderID,
		Longitude: p.Lng,
		Latitude:  p.Lat,
	})
	pipe.Set(ctx, statusKey(tenantID, p.ResponderID), string(p.Status), presenceTTL)

	_, err := pipe.Exec(ctx)
	return err
}

// SetOffline removes a responder from the geo index entirely — used on
// explicit sign-off rather than waiting for TTL expiry.
func (reg *Registry) SetOffline(ctx context.Context, tenantID, responderID string) error {
	pipe := reg.rdb.TxPipeline()
	pipe.ZRem(ctx, geoKey(tenantID), responderID)
	pipe.Del(ctx, statusKey(tenantID, responderID))
	_, err := pipe.Exec(ctx)
	return err
}

// NearestAvailable returns verified responder IDs within radiusKM of the
// given point, ranked nearest-first, filtered to "available" status.
// This is the hot path the dispatch service calls on every SOS.
func (reg *Registry) NearestAvailable(ctx context.Context, tenantID string, lat, lng, radiusKM float64, limit int) ([]models.ResponderPresence, error) {
	results, err := reg.rdb.GeoSearchLocation(ctx, geoKey(tenantID), &redis.GeoSearchLocationQuery{
		GeoSearchQuery: redis.GeoSearchQuery{
			Longitude:  lng,
			Latitude:   lat,
			Radius:     radiusKM,
			RadiusUnit: "km",
			Sort:       "ASC", // nearest first
			Count:      limit * 3, // over-fetch since we filter by status after
		},
		WithCoord: true,
	}).Result()
	if err != nil {
		return nil, fmt.Errorf("geo search: %w", err)
	}

	var available []models.ResponderPresence
	for _, res := range results {
		status, err := reg.rdb.Get(ctx, statusKey(tenantID, res.Name)).Result()
		if err == redis.Nil {
			continue // presence expired — treat as offline
		} else if err != nil {
			continue
		}
		if models.ResponderStatus(status) != models.ResponderAvailable {
			continue
		}
		available = append(available, models.ResponderPresence{
			ResponderID: res.Name,
			Lat:         res.Latitude,
			Lng:         res.Longitude,
			Status:      models.ResponderAvailable,
		})
		if len(available) >= limit {
			break
		}
	}
	return available, nil
}
