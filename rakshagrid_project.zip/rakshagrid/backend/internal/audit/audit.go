// Package audit owns the append-only incident record: every state
// transition an incident goes through gets written here and is never
// updated or deleted. This is the compliance backbone the whole business
// case rests on — auto-generated UGC/AICTE-aligned reports are built
// entirely from this log.
package audit

import (
	"context"
	"database/sql"
	"fmt"
	"time"

	"github.com/rishabhjha/rakshagrid/internal/models"
)

type Service struct {
	db *sql.DB
}

func NewService(db *sql.DB) *Service {
	return &Service{db: db}
}

// CreateIncident inserts the initial incident row and its "raised" event
// in one transaction — an incident without a founding event should be
// impossible.
func (s *Service) CreateIncident(ctx context.Context, inc models.Incident) (string, error) {
	tx, err := s.db.BeginTx(ctx, nil)
	if err != nil {
		return "", fmt.Errorf("begin tx: %w", err)
	}
	defer tx.Rollback()

	var id string
	err = tx.QueryRowContext(ctx, `
		INSERT INTO incidents (tenant_id, raised_by, type, lat, lng, status)
		VALUES ($1, $2, $3, $4, $5, $6)
		RETURNING id
	`, inc.TenantID, inc.RaisedBy, inc.Type, inc.Lat, inc.Lng, models.IncidentRaised).Scan(&id)
	if err != nil {
		return "", fmt.Errorf("insert incident: %w", err)
	}

	if err := s.logEventTx(ctx, tx, id, "raised", inc.RaisedBy, ""); err != nil {
		return "", err
	}

	if err := tx.Commit(); err != nil {
		return "", fmt.Errorf("commit tx: %w", err)
	}
	return id, nil
}

// LogEvent appends one event to an incident's timeline and, for terminal
// events, updates the incident's summary status/timestamp. The incidents
// row is a queryable *projection* of the event log for the admin
// dashboard — incident_events remains the source of truth.
func (s *Service) LogEvent(ctx context.Context, incidentID, eventType, actorID, detail string) error {
	tx, err := s.db.BeginTx(ctx, nil)
	if err != nil {
		return fmt.Errorf("begin tx: %w", err)
	}
	defer tx.Rollback()

	if err := s.logEventTx(ctx, tx, incidentID, eventType, actorID, detail); err != nil {
		return err
	}

	switch eventType {
	case "matched":
		_, err = tx.ExecContext(ctx, `UPDATE incidents SET status = $1, responder_id = $2 WHERE id = $3`,
			models.IncidentMatched, actorID, incidentID)
	case "acked":
		_, err = tx.ExecContext(ctx, `UPDATE incidents SET status = $1 WHERE id = $2`,
			models.IncidentAcked, incidentID)
	case "escalated":
		_, err = tx.ExecContext(ctx, `UPDATE incidents SET status = $1 WHERE id = $2`,
			models.IncidentEscalated, incidentID)
	case "resolved":
		_, err = tx.ExecContext(ctx, `UPDATE incidents SET status = $1, resolved_at = $2 WHERE id = $3`,
			models.IncidentResolved, time.Now(), incidentID)
	}
	if err != nil {
		return fmt.Errorf("update incident projection: %w", err)
	}

	return tx.Commit()
}

func (s *Service) logEventTx(ctx context.Context, tx *sql.Tx, incidentID, eventType, actorID, detail string) error {
	_, err := tx.ExecContext(ctx, `
		INSERT INTO incident_events (incident_id, event_type, actor_id, detail)
		VALUES ($1, $2, $3, $4)
	`, incidentID, eventType, actorID, detail)
	if err != nil {
		return fmt.Errorf("insert incident_event: %w", err)
	}
	return nil
}

// Timeline returns the full, ordered event history for one incident —
// what the admin dashboard renders for a single-incident drill-down.
func (s *Service) Timeline(ctx context.Context, incidentID string) ([]models.IncidentEvent, error) {
	rows, err := s.db.QueryContext(ctx, `
		SELECT id, incident_id, event_type, COALESCE(actor_id::text, 'system'), timestamp, COALESCE(detail, '')
		FROM incident_events WHERE incident_id = $1 ORDER BY timestamp ASC
	`, incidentID)
	if err != nil {
		return nil, fmt.Errorf("query timeline: %w", err)
	}
	defer rows.Close()

	var events []models.IncidentEvent
	for rows.Next() {
		var e models.IncidentEvent
		if err := rows.Scan(&e.ID, &e.IncidentID, &e.EventType, &e.ActorID, &e.Timestamp, &e.Detail); err != nil {
			return nil, fmt.Errorf("scan event: %w", err)
		}
		events = append(events, e)
	}
	return events, nil
}

// ComplianceReport is a minimal aggregate — average response time and
// incident counts by type — for a given tenant over a period. This is the
// sellable artifact referenced in the business-model section of the
// design doc; extend the SQL here as reporting requirements grow.
type ComplianceReport struct {
	TenantID           string             `json:"tenant_id"`
	PeriodStart        time.Time          `json:"period_start"`
	PeriodEnd          time.Time          `json:"period_end"`
	TotalIncidents     int                `json:"total_incidents"`
	ResolvedIncidents  int                `json:"resolved_incidents"`
	AvgResponseSeconds float64            `json:"avg_response_seconds"`
	IncidentsByType    map[string]int     `json:"incidents_by_type"`
}

func (s *Service) GenerateComplianceReport(ctx context.Context, tenantID string, start, end time.Time) (*ComplianceReport, error) {
	report := &ComplianceReport{
		TenantID:        tenantID,
		PeriodStart:     start,
		PeriodEnd:       end,
		IncidentsByType: make(map[string]int),
	}

	err := s.db.QueryRowContext(ctx, `
		SELECT COUNT(*), COUNT(*) FILTER (WHERE status = 'resolved'),
		       COALESCE(AVG(EXTRACT(EPOCH FROM (resolved_at - created_at))) FILTER (WHERE resolved_at IS NOT NULL), 0)
		FROM incidents WHERE tenant_id = $1 AND created_at BETWEEN $2 AND $3
	`, tenantID, start, end).Scan(&report.TotalIncidents, &report.ResolvedIncidents, &report.AvgResponseSeconds)
	if err != nil {
		return nil, fmt.Errorf("aggregate report: %w", err)
	}

	rows, err := s.db.QueryContext(ctx, `
		SELECT type, COUNT(*) FROM incidents
		WHERE tenant_id = $1 AND created_at BETWEEN $2 AND $3
		GROUP BY type
	`, tenantID, start, end)
	if err != nil {
		return nil, fmt.Errorf("group by type: %w", err)
	}
	defer rows.Close()
	for rows.Next() {
		var t string
		var c int
		if err := rows.Scan(&t, &c); err != nil {
			return nil, err
		}
		report.IncidentsByType[t] = c
	}

	return report, nil
}
