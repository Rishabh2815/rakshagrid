// Package dispatch is the heart of RakshaGrid: it takes a raised SOS,
// finds the nearest available verified responder via the responder
// registry, notifies them in real time, and hands off to audit for
// the immutable record. Auto-escalation on SLA breach lives here too.
//
// This package deliberately depends only on narrow interfaces
// (registryClient, notifier, auditor) rather than concrete types from
// responder/notify/audit — that's what lets dispatch_test.go exercise
// the full matching + escalation logic with fakes, no Redis/Postgres
// required.
package dispatch

import (
	"context"
	"fmt"
	"log"
	"time"

	"github.com/rishabhjha/rakshagrid/internal/models"
)

type registryClient interface {
	NearestAvailable(ctx context.Context, tenantID string, lat, lng, radiusKM float64, limit int) ([]models.ResponderPresence, error)
}

// auditor is intentionally narrower than the full audit.Service — dispatch
// only ever creates incidents and appends events, never reads reports.
type auditor interface {
	CreateIncident(ctx context.Context, inc models.Incident) (string, error)
	LogEvent(ctx context.Context, incidentID, eventType, actorID, detail string) error
}

type Service struct {
	registry    registryClient
	audit       auditor
	radiusKM    float64
	ackSLA      time.Duration
	fanOutCount int // how many responders to alert simultaneously
}

func NewService(registry registryClient, audit auditor, radiusKM float64, ackSLA time.Duration) *Service {
	return &Service{
		registry:    registry,
		audit:       audit,
		radiusKM:    radiusKM,
		ackSLA:      ackSLA,
		fanOutCount: 3, // alert the 3 nearest responders simultaneously
	}
}

// AckSLA exposes the configured SLA window so the API layer's background
// escalation sweeper (see cmd/server/main.go) can query incidents older
// than it without dispatch needing to own a scheduler itself.
func (s *Service) AckSLA() time.Duration { return s.ackSLA }

type RaiseSOSInput struct {
	TenantID string
	UserID   string
	Type     models.IncidentType
	Lat      float64
	Lng      float64
}

type RaiseSOSResult struct {
	IncidentID        string   `json:"incident_id"`
	MatchedResponders []string `json:"matched_responders"` // responder IDs alerted, nearest first
}

// RaiseSOS is the entry point called by the API layer when a user hits
// the SOS button. It performs the full match → persist → (caller notifies)
// flow. Actual WebSocket delivery is left to the caller (see api.Handlers)
// so this package stays testable without a live Hub.
func (s *Service) RaiseSOS(ctx context.Context, in RaiseSOSInput) (*RaiseSOSResult, error) {
	incidentID, err := s.audit.CreateIncident(ctx, models.Incident{
		TenantID: in.TenantID,
		RaisedBy: in.UserID,
		Type:     in.Type,
		Lat:      in.Lat,
		Lng:      in.Lng,
	})
	if err != nil {
		return nil, fmt.Errorf("create incident: %w", err)
	}

	candidates, err := s.registry.NearestAvailable(ctx, in.TenantID, in.Lat, in.Lng, s.radiusKM, s.fanOutCount)
	if err != nil {
		// The incident is already durably recorded even if matching fails —
		// an admin can still see and manually route it. We don't want a
		// Redis hiccup to make an SOS silently disappear.
		log.Printf("dispatch: geo search failed for incident %s: %v", incidentID, err)
		return &RaiseSOSResult{IncidentID: incidentID}, nil
	}

	var responderIDs []string
	for _, c := range candidates {
		responderIDs = append(responderIDs, c.ResponderID)
	}

	if len(responderIDs) == 0 {
		log.Printf("dispatch: no available responders found for incident %s (tenant=%s)", incidentID, in.TenantID)
		return &RaiseSOSResult{IncidentID: incidentID}, nil
	}

	if err := s.audit.LogEvent(ctx, incidentID, "matched", responderIDs[0], fmt.Sprintf("candidates=%v", responderIDs)); err != nil {
		log.Printf("dispatch: failed to log matched event: %v", err)
	}

	return &RaiseSOSResult{IncidentID: incidentID, MatchedResponders: responderIDs}, nil
}

// Ack records a responder accepting an incident. Whichever responder
// ACKs first wins — the API layer should treat a second ACK on an
// already-acked incident as a no-op (idempotent), not an error, since
// two responders can plausibly race.
func (s *Service) Ack(ctx context.Context, incidentID, responderID string) error {
	return s.audit.LogEvent(ctx, incidentID, "acked", responderID, "")
}

// Resolve closes out an incident.
func (s *Service) Resolve(ctx context.Context, incidentID, actorID, detail string) error {
	return s.audit.LogEvent(ctx, incidentID, "resolved", actorID, detail)
}

// Escalate is intended to be called by a background sweeper (see
// cmd/server/main.go) that polls for incidents past their ACK SLA with
// no acknowledgment and re-runs the match against the *next* ring of
// responders, excluding those already alerted.
func (s *Service) Escalate(ctx context.Context, incidentID, actorID, detail string) error {
	return s.audit.LogEvent(ctx, incidentID, "escalated", actorID, detail)
}
