package dispatch

import (
	"context"
	"testing"
	"time"

	"github.com/rishabhjha/rakshagrid/internal/models"
)

// fakeRegistry and fakeAuditor satisfy dispatch's narrow interfaces
// without touching Redis or Postgres — this is the payoff of dispatch
// depending on interfaces rather than concrete responder.Registry /
// audit.Service types.

type fakeRegistry struct {
	nearby []models.ResponderPresence
	err    error
}

func (f *fakeRegistry) NearestAvailable(ctx context.Context, tenantID string, lat, lng, radiusKM float64, limit int) ([]models.ResponderPresence, error) {
	if f.err != nil {
		return nil, f.err
	}
	if len(f.nearby) > limit {
		return f.nearby[:limit], nil
	}
	return f.nearby, nil
}

type fakeAuditor struct {
	incidents map[string]models.Incident
	events    []string // event_type log, in call order
	createErr error
}

func newFakeAuditor() *fakeAuditor {
	return &fakeAuditor{incidents: make(map[string]models.Incident)}
}

func (f *fakeAuditor) CreateIncident(ctx context.Context, inc models.Incident) (string, error) {
	if f.createErr != nil {
		return "", f.createErr
	}
	id := "incident-1"
	inc.ID = id
	f.incidents[id] = inc
	// Mirrors the real audit.Service: CreateIncident logs the founding
	// "raised" event in the same transaction as the insert.
	f.events = append(f.events, "raised")
	return id, nil
}

func (f *fakeAuditor) LogEvent(ctx context.Context, incidentID, eventType, actorID, detail string) error {
	f.events = append(f.events, eventType)
	return nil
}

func TestRaiseSOS_MatchesNearestResponder(t *testing.T) {
	registry := &fakeRegistry{
		nearby: []models.ResponderPresence{
			{ResponderID: "responder-near", Lat: 28.61, Lng: 77.20},
			{ResponderID: "responder-far", Lat: 28.70, Lng: 77.30},
		},
	}
	auditor := newFakeAuditor()
	svc := NewService(registry, auditor, 2.0, 60*time.Second)

	result, err := svc.RaiseSOS(context.Background(), RaiseSOSInput{
		TenantID: "tenant-1",
		UserID:   "user-1",
		Type:     models.IncidentSafety,
		Lat:      28.60,
		Lng:      77.19,
	})
	if err != nil {
		t.Fatalf("unexpected error: %v", err)
	}
	if result.IncidentID != "incident-1" {
		t.Errorf("expected incident-1, got %s", result.IncidentID)
	}
	if len(result.MatchedResponders) != 2 {
		t.Fatalf("expected 2 matched responders, got %d", len(result.MatchedResponders))
	}
	if result.MatchedResponders[0] != "responder-near" {
		t.Errorf("expected nearest responder first, got %s", result.MatchedResponders[0])
	}

	wantEvents := []string{"raised", "matched"}
	if len(auditor.events) != len(wantEvents) {
		t.Fatalf("expected events %v, got %v", wantEvents, auditor.events)
	}
	for i, e := range wantEvents {
		if auditor.events[i] != e {
			t.Errorf("event %d: expected %q, got %q", i, e, auditor.events[i])
		}
	}
}

func TestRaiseSOS_NoResponderAvailable_StillRecordsIncident(t *testing.T) {
	registry := &fakeRegistry{nearby: nil} // nobody nearby
	auditor := newFakeAuditor()
	svc := NewService(registry, auditor, 2.0, 60*time.Second)

	result, err := svc.RaiseSOS(context.Background(), RaiseSOSInput{
		TenantID: "tenant-1",
		UserID:   "user-1",
		Type:     models.IncidentMedical,
		Lat:      28.60,
		Lng:      77.19,
	})
	if err != nil {
		t.Fatalf("unexpected error: %v", err)
	}
	if result.IncidentID == "" {
		t.Fatal("expected incident to still be recorded even with no responders available")
	}
	if len(result.MatchedResponders) != 0 {
		t.Errorf("expected no matched responders, got %v", result.MatchedResponders)
	}
	// Only "raised" should be logged — no "matched" event since nobody was found.
	if len(auditor.events) != 1 || auditor.events[0] != "raised" {
		t.Errorf("expected only [raised], got %v", auditor.events)
	}
}

func TestRaiseSOS_RegistryFailure_DoesNotLoseTheIncident(t *testing.T) {
	registry := &fakeRegistry{err: context.DeadlineExceeded}
	auditor := newFakeAuditor()
	svc := NewService(registry, auditor, 2.0, 60*time.Second)

	result, err := svc.RaiseSOS(context.Background(), RaiseSOSInput{
		TenantID: "tenant-1",
		UserID:   "user-1",
		Type:     models.IncidentFire,
		Lat:      28.60,
		Lng:      77.19,
	})
	if err != nil {
		t.Fatalf("a Redis/geo failure must not fail the whole SOS: %v", err)
	}
	if result.IncidentID == "" {
		t.Fatal("incident must still be durably recorded even if matching fails")
	}
}

func TestFanOutRespectsConfiguredCount(t *testing.T) {
	var many []models.ResponderPresence
	for i := 0; i < 10; i++ {
		many = append(many, models.ResponderPresence{ResponderID: "r"})
	}
	registry := &fakeRegistry{nearby: many}
	auditor := newFakeAuditor()
	svc := NewService(registry, auditor, 2.0, 60*time.Second)

	result, _ := svc.RaiseSOS(context.Background(), RaiseSOSInput{
		TenantID: "tenant-1", UserID: "user-1", Type: models.IncidentSafety, Lat: 0, Lng: 0,
	})
	if len(result.MatchedResponders) != svc.fanOutCount {
		t.Errorf("expected fan-out of %d, got %d", svc.fanOutCount, len(result.MatchedResponders))
	}
}
