// Package auth handles user/responder identity: password hashing, JWT
// issuance, and the HTTP middleware that protects every other service's
// routes. Every other package in this monolith trusts auth.Claims coming
// out of the request context rather than re-deriving identity itself.
package auth

import (
	"context"
	"crypto/sha256"
	"crypto/subtle"
	"encoding/hex"
	"errors"
	"net/http"
	"strings"
	"time"

	"github.com/golang-jwt/jwt/v5"

	"github.com/rishabhjha/rakshagrid/internal/models"
)

var ErrInvalidCredentials = errors.New("invalid credentials")
var ErrMissingToken = errors.New("missing or malformed authorization header")

type ctxKey string

const claimsCtxKey ctxKey = "claims"

type Claims struct {
	UserID   string      `json:"uid"`
	TenantID string      `json:"tid"`
	Role     models.Role `json:"role"`
	jwt.RegisteredClaims
}

type Service struct {
	secret []byte
	expiry time.Duration
}

func NewService(secret string, expiry time.Duration) *Service {
	return &Service{secret: []byte(secret), expiry: expiry}
}

// HashPassword uses SHA-256 with a static pepper for this reference
// implementation. Production deployments should swap this for bcrypt/argon2
// (see README "Hardening before production").
func (s *Service) HashPassword(password string) string {
	h := sha256.Sum256([]byte("rakshagrid-pepper:" + password))
	return hex.EncodeToString(h[:])
}

func (s *Service) VerifyPassword(password, hash string) bool {
	computed := s.HashPassword(password)
	return subtle.ConstantTimeCompare([]byte(computed), []byte(hash)) == 1
}

func (s *Service) IssueToken(user models.User) (string, error) {
	claims := Claims{
		UserID:   user.ID,
		TenantID: user.TenantID,
		Role:     user.Role,
		RegisteredClaims: jwt.RegisteredClaims{
			ExpiresAt: jwt.NewNumericDate(time.Now().Add(s.expiry)),
			IssuedAt:  jwt.NewNumericDate(time.Now()),
		},
	}
	token := jwt.NewWithClaims(jwt.SigningMethodHS256, claims)
	return token.SignedString(s.secret)
}

func (s *Service) ParseToken(tokenStr string) (*Claims, error) {
	claims := &Claims{}
	token, err := jwt.ParseWithClaims(tokenStr, claims, func(t *jwt.Token) (interface{}, error) {
		return s.secret, nil
	})
	if err != nil || !token.Valid {
		return nil, errors.New("invalid token")
	}
	return claims, nil
}

// Middleware validates the Authorization: Bearer <token> header and
// injects Claims into the request context. Handlers pull identity via
// FromContext rather than re-parsing the header themselves.
func (s *Service) Middleware(next http.Handler) http.Handler {
	return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		header := r.Header.Get("Authorization")
		if !strings.HasPrefix(header, "Bearer ") {
			http.Error(w, ErrMissingToken.Error(), http.StatusUnauthorized)
			return
		}
		tokenStr := strings.TrimPrefix(header, "Bearer ")
		claims, err := s.ParseToken(tokenStr)
		if err != nil {
			http.Error(w, "invalid or expired token", http.StatusUnauthorized)
			return
		}
		ctx := context.WithValue(r.Context(), claimsCtxKey, claims)
		next.ServeHTTP(w, r.WithContext(ctx))
	})
}

func FromContext(ctx context.Context) (*Claims, bool) {
	claims, ok := ctx.Value(claimsCtxKey).(*Claims)
	return claims, ok
}
