// Package api is the HTTP edge of the monolith: it wires every internal
// service (auth, dispatch, responder, audit, tenant, notify) behind a
// single chi router. This is intentionally the only package that imports
// all the others — every other service package stays decoupled from HTTP
// concerns entirely, which is what makes them individually testable and
// what makes a future split into separate deployables mechanical rather
// than a rewrite.
package api

import (
	"database/sql"
	"net/http"
	"time"

	"github.com/go-chi/chi/v5"
	"github.com/go-chi/chi/v5/middleware"
	"github.com/redis/go-redis/v9"

	"github.com/rishabhjha/rakshagrid/internal/audit"
	"github.com/rishabhjha/rakshagrid/internal/auth"
	"github.com/rishabhjha/rakshagrid/internal/dispatch"
	"github.com/rishabhjha/rakshagrid/internal/notify"
	"github.com/rishabhjha/rakshagrid/internal/responder"
	"github.com/rishabhjha/rakshagrid/internal/tenant"
)

type Handlers struct {
	authSvc     *auth.Service
	dispatchSvc *dispatch.Service
	responderReg *responder.Registry
	auditSvc    *audit.Service
	tenantSvc   *tenant.Service
	hub         *notify.Hub
	db          *sql.DB
}

func NewRouter(db *sql.DB, rdb *redis.Client, authSvc *auth.Service, jwtExpiry time.Duration, radiusKM float64, ackSLA time.Duration) http.Handler {
	responderReg := responder.NewRegistry(rdb)
	auditSvc := audit.NewService(db)
	tenantSvc := tenant.NewService(db)
	hub := notify.NewHub()
	dispatchSvc := dispatch.NewService(responderReg, auditSvc, radiusKM, ackSLA)

	h := &Handlers{
		authSvc:      authSvc,
		dispatchSvc:  dispatchSvc,
		responderReg: responderReg,
		auditSvc:     auditSvc,
		tenantSvc:    tenantSvc,
		hub:          hub,
		db:           db,
	}

	r := chi.NewRouter()
	r.Use(middleware.RequestID)
	r.Use(middleware.RealIP)
	r.Use(middleware.Logger)
	r.Use(middleware.Recoverer)
	r.Use(middleware.Timeout(15 * time.Second))

	r.Get("/healthz", h.health)

	r.Route("/v1", func(r chi.Router) {
		// Public
		r.Post("/tenants", h.createTenant)
		r.Post("/auth/register", h.register)
		r.Post("/auth/login", h.login)

		// Authenticated
		r.Group(func(r chi.Router) {
			r.Use(authSvc.Middleware)

			r.Post("/sos", h.raiseSOS)
			r.Get("/incidents/{id}", h.getIncident)
			r.Post("/incidents/{id}/ack", h.ackIncident)
			r.Post("/incidents/{id}/resolve", h.resolveIncident)

			r.Post("/responders/heartbeat", h.responderHeartbeat)
			r.Post("/responders/offline", h.responderOffline)

			r.Get("/admin/incidents/{id}/timeline", h.incidentTimeline)
			r.Get("/admin/compliance-report", h.complianceReport)

			r.Get("/stream", h.stream)
		})
	})

	return r
}

func (h *Handlers) health(w http.ResponseWriter, r *http.Request) {
	w.WriteHeader(http.StatusOK)
	w.Write([]byte(`{"status":"ok"}`))
}
