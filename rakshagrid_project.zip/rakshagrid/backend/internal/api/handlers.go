package api

import (
	"context"
	"encoding/json"
	"net/http"
	"time"

	"github.com/go-chi/chi/v5"
	"github.com/coder/websocket"

	"github.com/rishabhjha/rakshagrid/internal/auth"
	"github.com/rishabhjha/rakshagrid/internal/dispatch"
	"github.com/rishabhjha/rakshagrid/internal/models"
	"github.com/rishabhjha/rakshagrid/internal/notify"
)

func writeJSON(w http.ResponseWriter, status int, v interface{}) {
	w.Header().Set("Content-Type", "application/json")
	w.WriteHeader(status)
	json.NewEncoder(w).Encode(v)
}

func writeError(w http.ResponseWriter, status int, msg string) {
	writeJSON(w, status, map[string]string{"error": msg})
}

// --- Tenant onboarding ---

type createTenantReq struct {
	Name     string `json:"name"`
	Region   string `json:"region"`
	PlanTier string `json:"plan_tier"`
}

func (h *Handlers) createTenant(w http.ResponseWriter, r *http.Request) {
	var req createTenantReq
	if err := json.NewDecoder(r.Body).Decode(&req); err != nil || req.Name == "" {
		writeError(w, http.StatusBadRequest, "name is required")
		return
	}
	t, err := h.tenantSvc.Create(r.Context(), req.Name, req.Region, req.PlanTier)
	if err != nil {
		writeError(w, http.StatusInternalServerError, "failed to create tenant")
		return
	}
	writeJSON(w, http.StatusCreated, t)
}

// --- Auth ---

type registerReq struct {
	TenantID string `json:"tenant_id"`
	Name     string `json:"name"`
	Email    string `json:"email"`
	Password string `json:"password"`
	Role     string `json:"role"`
}

func (h *Handlers) register(w http.ResponseWriter, r *http.Request) {
	var req registerReq
	if err := json.NewDecoder(r.Body).Decode(&req); err != nil {
		writeError(w, http.StatusBadRequest, "invalid request body")
		return
	}
	if req.TenantID == "" || req.Email == "" || req.Password == "" {
		writeError(w, http.StatusBadRequest, "tenant_id, email, and password are required")
		return
	}
	role := models.Role(req.Role)
	if role == "" {
		role = models.RoleStudent
	}

	hash := h.authSvc.HashPassword(req.Password)
	var u models.User
	err := h.db.QueryRowContext(r.Context(), `
		INSERT INTO users (tenant_id, name, email, password_hash, role)
		VALUES ($1, $2, $3, $4, $5)
		RETURNING id, tenant_id, name, email, role, verified, created_at
	`, req.TenantID, req.Name, req.Email, hash, role).Scan(
		&u.ID, &u.TenantID, &u.Name, &u.Email, &u.Role, &u.Verified, &u.CreatedAt,
	)
	if err != nil {
		writeError(w, http.StatusConflict, "could not register user (email may already be in use)")
		return
	}

	token, err := h.authSvc.IssueToken(u)
	if err != nil {
		writeError(w, http.StatusInternalServerError, "failed to issue token")
		return
	}
	writeJSON(w, http.StatusCreated, map[string]interface{}{"user": u, "token": token})
}

type loginReq struct {
	TenantID string `json:"tenant_id"`
	Email    string `json:"email"`
	Password string `json:"password"`
}

func (h *Handlers) login(w http.ResponseWriter, r *http.Request) {
	var req loginReq
	if err := json.NewDecoder(r.Body).Decode(&req); err != nil {
		writeError(w, http.StatusBadRequest, "invalid request body")
		return
	}

	var u models.User
	err := h.db.QueryRowContext(r.Context(), `
		SELECT id, tenant_id, name, email, password_hash, role, verified, created_at
		FROM users WHERE tenant_id = $1 AND email = $2
	`, req.TenantID, req.Email).Scan(
		&u.ID, &u.TenantID, &u.Name, &u.Email, &u.PasswordHash, &u.Role, &u.Verified, &u.CreatedAt,
	)
	if err != nil || !h.authSvc.VerifyPassword(req.Password, u.PasswordHash) {
		writeError(w, http.StatusUnauthorized, auth.ErrInvalidCredentials.Error())
		return
	}

	token, err := h.authSvc.IssueToken(u)
	if err != nil {
		writeError(w, http.StatusInternalServerError, "failed to issue token")
		return
	}
	writeJSON(w, http.StatusOK, map[string]interface{}{"user": u, "token": token})
}

// --- SOS dispatch ---

type raiseSOSReq struct {
	Type models.IncidentType `json:"type"`
	Lat  float64              `json:"lat"`
	Lng  float64              `json:"lng"`
}

func (h *Handlers) raiseSOS(w http.ResponseWriter, r *http.Request) {
	claims, ok := auth.FromContext(r.Context())
	if !ok {
		writeError(w, http.StatusUnauthorized, "missing identity")
		return
	}

	var req raiseSOSReq
	if err := json.NewDecoder(r.Body).Decode(&req); err != nil {
		writeError(w, http.StatusBadRequest, "invalid request body")
		return
	}

	result, err := h.dispatchSvc.RaiseSOS(r.Context(), dispatch.RaiseSOSInput{
		TenantID: claims.TenantID,
		UserID:   claims.UserID,
		Type:     req.Type,
		Lat:      req.Lat,
		Lng:      req.Lng,
	})
	if err != nil {
		writeError(w, http.StatusInternalServerError, "failed to raise SOS")
		return
	}

	// Fan out real-time alerts to matched responders. This lives at the API
	// layer (not inside dispatch.Service) precisely so dispatch stays
	// testable without a live Hub — see dispatch.go's package doc.
	if len(result.MatchedResponders) > 0 {
		payload, _ := json.Marshal(map[string]interface{}{
			"incident_id": result.IncidentID,
			"type":        req.Type,
			"lat":         req.Lat,
			"lng":         req.Lng,
		})
		h.hub.Broadcast(r.Context(), result.MatchedResponders, notify.Message{
			Type:    "sos_alert",
			Payload: payload,
		})
	}

	writeJSON(w, http.StatusCreated, result)
}

func (h *Handlers) getIncident(w http.ResponseWriter, r *http.Request) {
	id := chi.URLParam(r, "id")
	var inc models.Incident
	err := h.db.QueryRowContext(r.Context(), `
		SELECT id, tenant_id, raised_by, type, lat, lng, status, responder_id, created_at, resolved_at
		FROM incidents WHERE id = $1
	`, id).Scan(&inc.ID, &inc.TenantID, &inc.RaisedBy, &inc.Type, &inc.Lat, &inc.Lng,
		&inc.Status, &inc.ResponderID, &inc.CreatedAt, &inc.ResolvedAt)
	if err != nil {
		writeError(w, http.StatusNotFound, "incident not found")
		return
	}
	writeJSON(w, http.StatusOK, inc)
}

func (h *Handlers) ackIncident(w http.ResponseWriter, r *http.Request) {
	claims, _ := auth.FromContext(r.Context())
	id := chi.URLParam(r, "id")
	if err := h.dispatchSvc.Ack(r.Context(), id, claims.UserID); err != nil {
		writeError(w, http.StatusInternalServerError, "failed to ack incident")
		return
	}

	// Notify the user that help is on the way.
	payload, _ := json.Marshal(map[string]string{"incident_id": id, "responder_id": claims.UserID})
	h.notifyIncidentOwner(r.Context(), id, notify.Message{Type: "status_update", Payload: payload})

	writeJSON(w, http.StatusOK, map[string]string{"status": "acked"})
}

type resolveReq struct {
	Detail string `json:"detail"`
}

func (h *Handlers) resolveIncident(w http.ResponseWriter, r *http.Request) {
	claims, _ := auth.FromContext(r.Context())
	id := chi.URLParam(r, "id")
	var req resolveReq
	json.NewDecoder(r.Body).Decode(&req) // detail is optional

	if err := h.dispatchSvc.Resolve(r.Context(), id, claims.UserID, req.Detail); err != nil {
		writeError(w, http.StatusInternalServerError, "failed to resolve incident")
		return
	}

	payload, _ := json.Marshal(map[string]string{"incident_id": id})
	h.notifyIncidentOwner(r.Context(), id, notify.Message{Type: "incident_resolved", Payload: payload})

	writeJSON(w, http.StatusOK, map[string]string{"status": "resolved"})
}

// notifyIncidentOwner looks up who raised an incident and pushes them a
// status update. A small helper rather than a full pub/sub topic, since
// v1 only ever notifies the single raising user.
func (h *Handlers) notifyIncidentOwner(ctx context.Context, incidentID string, msg notify.Message) {
	var raisedBy string
	if err := h.db.QueryRowContext(ctx, `SELECT raised_by FROM incidents WHERE id = $1`, incidentID).Scan(&raisedBy); err != nil {
		return
	}
	h.hub.Send(ctx, raisedBy, msg)
}

// --- Responder presence ---

type heartbeatReq struct {
	Lat float64 `json:"lat"`
	Lng float64 `json:"lng"`
}

func (h *Handlers) responderHeartbeat(w http.ResponseWriter, r *http.Request) {
	claims, _ := auth.FromContext(r.Context())
	var req heartbeatReq
	if err := json.NewDecoder(r.Body).Decode(&req); err != nil {
		writeError(w, http.StatusBadRequest, "invalid request body")
		return
	}

	err := h.responderReg.Heartbeat(r.Context(), claims.TenantID, models.ResponderPresence{
		ResponderID: claims.UserID,
		Lat:         req.Lat,
		Lng:         req.Lng,
		Status:      models.ResponderAvailable,
	})
	if err != nil {
		writeError(w, http.StatusInternalServerError, "failed to record heartbeat")
		return
	}
	writeJSON(w, http.StatusOK, map[string]string{"status": "ok"})
}

func (h *Handlers) responderOffline(w http.ResponseWriter, r *http.Request) {
	claims, _ := auth.FromContext(r.Context())
	if err := h.responderReg.SetOffline(r.Context(), claims.TenantID, claims.UserID); err != nil {
		writeError(w, http.StatusInternalServerError, "failed to go offline")
		return
	}
	writeJSON(w, http.StatusOK, map[string]string{"status": "offline"})
}

// --- Admin / compliance ---

func (h *Handlers) incidentTimeline(w http.ResponseWriter, r *http.Request) {
	id := chi.URLParam(r, "id")
	events, err := h.auditSvc.Timeline(r.Context(), id)
	if err != nil {
		writeError(w, http.StatusInternalServerError, "failed to fetch timeline")
		return
	}
	writeJSON(w, http.StatusOK, events)
}

func (h *Handlers) complianceReport(w http.ResponseWriter, r *http.Request) {
	claims, _ := auth.FromContext(r.Context())

	end := time.Now()
	start := end.AddDate(0, -1, 0) // default: trailing 30 days

	report, err := h.auditSvc.GenerateComplianceReport(r.Context(), claims.TenantID, start, end)
	if err != nil {
		writeError(w, http.StatusInternalServerError, "failed to generate report")
		return
	}
	writeJSON(w, http.StatusOK, report)
}

// --- Realtime stream ---

func (h *Handlers) stream(w http.ResponseWriter, r *http.Request) {
	claims, ok := auth.FromContext(r.Context())
	if !ok {
		writeError(w, http.StatusUnauthorized, "missing identity")
		return
	}

	conn, err := websocket.Accept(w, r, &websocket.AcceptOptions{
		OriginPatterns: []string{"*"}, // tighten before production — see README
	})
	if err != nil {
		return
	}
	defer conn.CloseNow()

	h.hub.Register(claims.UserID, conn)
	defer h.hub.Unregister(claims.UserID)

	ctx := conn.CloseRead(r.Context()) // this connection is push-only from server to client
	<-ctx.Done()
}
