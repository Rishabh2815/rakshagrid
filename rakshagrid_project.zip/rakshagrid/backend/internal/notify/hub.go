// Package notify runs the real-time transport layer: a WebSocket hub that
// pushes SOS alerts to responders and status updates back to users. A
// push-notification fallback path exists (SendPush) for clients whose
// WebSocket connection has dropped — it's a stub here since it depends on
// a mobile push provider, but the interface is what the dispatch service
// codes against, so swapping in a real provider later doesn't touch
// dispatch logic at all.
package notify

import (
	"context"
	"encoding/json"
	"log"
	"sync"

	"github.com/coder/websocket"
)

type Message struct {
	Type    string          `json:"type"` // "sos_alert" | "status_update" | "incident_resolved"
	Payload json.RawMessage `json:"payload"`
}

type Hub struct {
	mu    sync.RWMutex
	conns map[string]*websocket.Conn // userID -> connection
}

func NewHub() *Hub {
	return &Hub{conns: make(map[string]*websocket.Conn)}
}

// Register binds a userID to its live WebSocket connection. Call this
// from the /v1/stream handler right after upgrading the connection.
func (h *Hub) Register(userID string, conn *websocket.Conn) {
	h.mu.Lock()
	defer h.mu.Unlock()
	h.conns[userID] = conn
}

func (h *Hub) Unregister(userID string) {
	h.mu.Lock()
	defer h.mu.Unlock()
	delete(h.conns, userID)
}

// Send delivers a message to one user if they have a live connection.
// Returns false if the user isn't connected — callers should treat that
// as "fall back to push notification", not an error.
func (h *Hub) Send(ctx context.Context, userID string, msg Message) bool {
	h.mu.RLock()
	conn, ok := h.conns[userID]
	h.mu.RUnlock()
	if !ok {
		return false
	}

	data, err := json.Marshal(msg)
	if err != nil {
		log.Printf("notify: marshal error: %v", err)
		return false
	}

	if err := conn.Write(ctx, websocket.MessageText, data); err != nil {
		log.Printf("notify: write error for user %s: %v", userID, err)
		h.Unregister(userID)
		return false
	}
	return true
}

// SendPush is the fallback path for a user with no live WebSocket
// connection. Stubbed pending a real push provider (FCM/APNs) — see
// README "Hardening before production".
func (h *Hub) SendPush(ctx context.Context, userID string, msg Message) {
	log.Printf("notify: [push-fallback] would push to user %s: type=%s", userID, msg.Type)
}

// Broadcast delivers to multiple users (used for SOS fan-out to top-N
// nearest responders), returning the subset that were actually delivered
// live so the dispatch service knows who to expect an ACK from.
func (h *Hub) Broadcast(ctx context.Context, userIDs []string, msg Message) []string {
	var delivered []string
	for _, id := range userIDs {
		if h.Send(ctx, id, msg) {
			delivered = append(delivered, id)
		} else {
			h.SendPush(ctx, id, msg)
		}
	}
	return delivered
}
