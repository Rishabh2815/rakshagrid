// Package config centralizes every environment-driven setting the app
// needs. Loading it once at startup (rather than reading os.Getenv
// scattered through the codebase) keeps every service's dependencies
// explicit and testable.
package config

import (
	"os"
	"strconv"
	"time"
)

type Config struct {
	HTTPPort          string
	PostgresDSN       string
	RedisAddr         string
	RedisPassword     string
	JWTSecret         string
	JWTExpiry         time.Duration
	SOSAckSLA         time.Duration // window a responder has to ACK before auto-escalation
	DispatchRadiusKM  float64       // initial geo-search radius for nearest-responder matching
}

func Load() Config {
	return Config{
		HTTPPort:         getEnv("HTTP_PORT", "8080"),
		PostgresDSN:      getEnv("POSTGRES_DSN", "postgres://rakshagrid:rakshagrid@localhost:5432/rakshagrid?sslmode=disable"),
		RedisAddr:        getEnv("REDIS_ADDR", "localhost:6379"),
		RedisPassword:    getEnv("REDIS_PASSWORD", ""),
		JWTSecret:        getEnv("JWT_SECRET", "dev-secret-change-me"),
		JWTExpiry:        getDurationEnv("JWT_EXPIRY", 24*time.Hour),
		SOSAckSLA:        getDurationEnv("SOS_ACK_SLA", 60*time.Second),
		DispatchRadiusKM: getFloatEnv("DISPATCH_RADIUS_KM", 2.0),
	}
}

func getEnv(key, fallback string) string {
	if v := os.Getenv(key); v != "" {
		return v
	}
	return fallback
}

func getDurationEnv(key string, fallback time.Duration) time.Duration {
	if v := os.Getenv(key); v != "" {
		if d, err := time.ParseDuration(v); err == nil {
			return d
		}
	}
	return fallback
}

func getFloatEnv(key string, fallback float64) float64 {
	if v := os.Getenv(key); v != "" {
		if f, err := strconv.ParseFloat(v, 64); err == nil {
			return f
		}
	}
	return fallback
}
