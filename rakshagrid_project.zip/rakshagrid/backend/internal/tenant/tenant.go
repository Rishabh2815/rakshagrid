// Package tenant manages campus (tenant) onboarding. This is the
// business-model layer: every institute that signs up is a row here,
// and plan_tier is what the future billing integration keys off.
package tenant

import (
	"context"
	"database/sql"
	"fmt"

	"github.com/rishabhjha/rakshagrid/internal/models"
)

type Service struct {
	db *sql.DB
}

func NewService(db *sql.DB) *Service {
	return &Service{db: db}
}

func (s *Service) Create(ctx context.Context, name, region, planTier string) (*models.Tenant, error) {
	if planTier == "" {
		planTier = "trial"
	}
	if region == "" {
		region = "ap-south-1"
	}

	var t models.Tenant
	err := s.db.QueryRowContext(ctx, `
		INSERT INTO tenants (name, region, plan_tier)
		VALUES ($1, $2, $3)
		RETURNING id, name, region, plan_tier, created_at
	`, name, region, planTier).Scan(&t.ID, &t.Name, &t.Region, &t.PlanTier, &t.CreatedAt)
	if err != nil {
		return nil, fmt.Errorf("insert tenant: %w", err)
	}
	return &t, nil
}

func (s *Service) Get(ctx context.Context, id string) (*models.Tenant, error) {
	var t models.Tenant
	err := s.db.QueryRowContext(ctx, `
		SELECT id, name, region, plan_tier, created_at FROM tenants WHERE id = $1
	`, id).Scan(&t.ID, &t.Name, &t.Region, &t.PlanTier, &t.CreatedAt)
	if err == sql.ErrNoRows {
		return nil, fmt.Errorf("tenant not found: %s", id)
	}
	if err != nil {
		return nil, fmt.Errorf("query tenant: %w", err)
	}
	return &t, nil
}
