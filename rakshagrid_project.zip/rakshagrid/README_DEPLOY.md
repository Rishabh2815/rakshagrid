# Deployment Guide

Full walkthroughs for getting RakshaGrid running somewhere other than your own machine. For local development, see the main [README](README.md#-quick-start) — this doc is specifically about deploying it.

## Vercel

Vercel runs both `backend/Dockerfile` and `frontend/Dockerfile` as separate
**services** inside one project — see the root `vercel.json`. Requests to
`/v1/*` and `/healthz` route straight to the Go backend container;
everything else routes to the frontend. Because both live under the same
domain, the frontend's relative `/v1/...` calls (the `api.js` default
when `VITE_API_URL` is unset) just work — no CORS configuration needed.

1. **Push this repo to GitHub**, then import it in the Vercel dashboard
   (or run `vercel deploy` from the project root with the Vercel CLI).
   Vercel picks up `vercel.json` automatically and builds both services.
2. **Add managed Postgres and Redis from the Vercel Marketplace**
   (Storage tab → e.g. Neon for Postgres, Upstash for Redis). For Redis,
   make sure you enable/copy the **standard Redis-protocol (TCP+TLS)
   connection string**, not just a REST endpoint — the backend uses
   `go-redis`, a normal Redis client, not an HTTP API.
3. **Set the backend service's environment variables** in Project
   Settings: `POSTGRES_DSN` and `REDIS_ADDR` from the connection strings
   the Marketplace integrations give you, plus `JWT_SECRET` (a real
   random value, not the dev default).
4. **Apply the schema once** — run `backend/migrations/0001_init.sql`
   against the Postgres instance (Neon's dashboard has a SQL console, or
   connect with `psql` using its connection string).
5. **Deploy.** Vercel builds both Dockerfiles, stores them in the Vercel
   Container Registry, and serves them behind Fluid compute. First deploy
   takes a few minutes; subsequent ones are faster.

Two things worth knowing about this specific deployment shape, both
because they're genuine constraints and because being able to name them
is useful in a demo Q&A:

- **Containers on Vercel are stateless and can scale to multiple
  instances.** `notify.Hub`'s in-memory `map[userID]*websocket.Conn`
  (see `internal/notify/hub.go`) only works correctly when all connected
  users happen to land on the same instance — true almost all the time at
  hackathon-demo traffic levels (Fluid compute keeps one instance warm),
  but not a guarantee at real scale. The fix, when it matters, is to back
  presence/delivery with the Redis instance you already provisioned
  instead of an in-process map — flagged here rather than silently
  glossed over.
- **Idle scale-down**: a service with no traffic for 5 minutes in
  production scales to zero and gets `SIGTERM` with a 30s grace period.
  `cmd/server/main.go` already handles `SIGTERM` gracefully (it was
  written for Docker's stop signal originally), so this isn't a new
  problem — just know the first request after idle time will be a cold
  start.

## Railway or Render

If you'd rather run frontend and backend as fully separate services on
different domains instead of Vercel's single-project model, the code
already supports it (`ALLOWED_ORIGINS` for CORS, `VITE_API_URL` for a
cross-domain frontend) — here's the Railway path, since it has the more
visual multi-service setup:

1. **Push this repo to GitHub** — Railway deploys from a GitHub repo or a
   Docker image, not a local zip.
2. **Create a Railway project**, then add two managed plugins from its
   dashboard: **PostgreSQL** and **Redis**. Railway gives you connection
   strings for both as environment variables automatically.
3. **Add a service from your repo, root directory `backend/`** (it'll
   detect the `Dockerfile`). Set its environment variables:
   - `POSTGRES_DSN` → reference Railway's Postgres plugin variable
   - `REDIS_ADDR` → reference Railway's Redis plugin variable (host:port form)
   - `JWT_SECRET` → generate a real random secret, not the dev default
   - `ALLOWED_ORIGINS` → the frontend's URL once you have it (step 5)
   Run the SQL in `backend/migrations/0001_init.sql` against the Postgres
   plugin once (Railway's dashboard has a query console for this, or
   connect with `psql` using the provided connection string).
4. **Note the backend service's public URL** Railway assigns it
   (`https://<something>.up.railway.app`).
5. **Add a second service from the same repo, root directory `frontend/`**.
   Set `VITE_API_URL` to the backend URL from step 4 **before it builds**
   — it's baked into the static bundle at build time, not read at runtime
   (see `src/api.js`). Railway will assign this service its own public URL.
6. **Go back to the backend service** and set `ALLOWED_ORIGINS` to the
   frontend's URL from step 5, then redeploy the backend so CORS actually
   allows it.

Render's flow is the same shape (separate web services + managed Postgres/
Redis add-ons), just via Render's dashboard terminology instead of
Railway's. Either way, budget for the fact that free/hobby tiers on both
platforms can cold-start or sleep after inactivity — worth a warm-up
request a few minutes before you actually demo.
