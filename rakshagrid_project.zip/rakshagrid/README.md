# RakshaGrid

Offline-resilient hyperlocal emergency response mesh. Full write-up of the
architecture and business-scaling rationale lives in
`docs/RakshaGrid_System_Design.md` — this README is just "how do I run it."

## Stack

- **Backend:** Go (modular monolith), chi router, PostgreSQL, Redis
  (geospatial matching), `coder/websocket` for realtime.
- **Frontend:** React + Vite, offline-first PWA (service worker + IndexedDB
  SOS queueing + Background Sync).
- **Infra:** Docker Compose for local dev; see the design doc for the
  multi-region AWS deployment story.

## Running locally

```bash
docker compose up --build
```

This starts Postgres (with the schema in `backend/migrations/0001_init.sql`
auto-applied on first boot), Redis, the Go backend on `:8080`, and the
frontend on `:3000`.

Without Docker, for backend development:

```bash
cd backend
go mod download
go run ./cmd/server
# requires POSTGRES_DSN and REDIS_ADDR env vars pointing at running instances
```

```bash
cd frontend
npm install
npm run dev
# proxies /v1 to localhost:8080 — see vite.config.js
```

## Running the tests

```bash
cd backend
go test ./...
```

`internal/dispatch` is unit-tested against interface fakes (no live
Redis/Postgres needed) — see `dispatch_test.go`. Everything else is
integration-shaped and is exercised via the running stack; adding
integration tests against a real Postgres/Redis (e.g. via `testcontainers-go`)
is a natural next step once the API surface stabilizes.

## Project layout

```
backend/
  cmd/server/         entrypoint: wiring + graceful shutdown + escalation sweeper
  internal/models/     shared domain types
  internal/config/      env-driven config
  internal/db/          Postgres + Redis connection setup
  internal/auth/        password hashing, JWT, HTTP middleware
  internal/responder/   Redis geospatial presence registry (the matching engine)
  internal/notify/      WebSocket hub — real-time alert fan-out
  internal/audit/       append-only incident log + compliance reports
  internal/dispatch/    core SOS orchestration (unit tested)
  internal/tenant/      campus onboarding
  internal/api/         HTTP routes + handlers, the only package that wires everything
  migrations/           SQL schema
frontend/
  public/sw.js          the offline-first service worker — the actual "works without
                         internet" implementation, not just a UI claim
  src/api.js             API client + WebSocket reconnect logic
  src/pages/              LoginForm, SOSButton, ResponderDashboard, AdminDashboard
docs/
  RakshaGrid_System_Design.md   full HLD write-up
  *.mermaid                      architecture diagrams referenced from the doc
```

## What's a reference implementation vs. production-ready

Built and verified to actually compile, pass `go vet`, and pass its tests —
this is real working code, not pseudocode. That said, a few things are
intentionally simplified for a hackathon/MVP stage and are flagged inline
in comments where they occur:

- **Password hashing** uses SHA-256 + a static pepper for simplicity.
  Swap for bcrypt or argon2 before handling real user data.
- **WebSocket auth** — browsers don't allow custom headers on the WS
  handshake; `src/api.js` notes this. Production should pass a short-lived
  token via query param or a cookie set at login instead.
- **Push notification fallback** (`notify.SendPush`) is a logging stub —
  wire up FCM/APNs when a mobile shell exists.
- **CORS/origin checks** on the WebSocket accept are wide open
  (`OriginPatterns: []string{"*"}`) for local dev — restrict before deploy.
- **Escalation sweeper** is a polling loop, fine for a single instance;
  see the design doc's growth-path table for when to replace it with a
  proper delayed-job queue.

None of these are hard problems — they're the specific, named list of
what to harden before this goes from "MVP for a hackathon + pilot campus"
to "handling a real campus's actual emergencies," which is itself a
useful thing to be able to say out loud to a judge.
