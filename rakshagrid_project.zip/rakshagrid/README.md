<div align="center">

# 🛡️ RakshaGrid

**An offline-resilient, hyperlocal emergency response mesh.**

One tap raises a verified SOS and geo-matches it to the nearest available responder — in real time, and *even when the internet is down.*

[![Go](https://img.shields.io/badge/Go-1.22-00ADD8?logo=go&logoColor=white)](https://go.dev)
[![React](https://img.shields.io/badge/React-18-61DAFB?logo=react&logoColor=black)](https://react.dev)
[![PostgreSQL](https://img.shields.io/badge/PostgreSQL-16-4169E1?logo=postgresql&logoColor=white)](https://www.postgresql.org)
[![Redis](https://img.shields.io/badge/Redis-7-DC382D?logo=redis&logoColor=white)](https://redis.io)
[![Docker](https://img.shields.io/badge/Docker-Compose-2496ED?logo=docker&logoColor=white)](https://www.docker.com)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](./LICENSE)

[Quick Start](#-quick-start) · [Architecture](#-architecture) · [Deployment](#-deployment) · [System Design Doc](docs/RakshaGrid_System_Design.md)

</div>

---

## The problem

Campus emergencies — harassment, medical, fire, security — lose critical time because centralized helplines route through one desk and fail exactly where connectivity is weakest: hostels, basements, crowded events. GPS-only systems are unreliable indoors, and there's no accountability trail for institutes that need to report on safety compliance (UGC/AICTE mandates).

## What RakshaGrid does

- **One-tap SOS**, geo-matched to the nearest *verified* responder (warden, security, or trained volunteer) via Redis geospatial search — typically sub-second.
- **Works without internet.** The client is an offline-first PWA: a service worker queues SOS requests in IndexedDB and flushes them via Background Sync the instant connectivity returns. This is the actual differentiator, not a slide — see `frontend/public/sw.js`.
- **Real-time dispatch**, over WebSockets, with auto-escalation if no responder acknowledges within the SLA window.
- **An immutable audit trail** for every incident, feeding an admin compliance dashboard — the sellable core of the business model (see the [system design doc](docs/RakshaGrid_System_Design.md) §5).

## ✨ Features

| | |
|---|---|
| 🆘 **Verified SOS dispatch** | Redis `GEOSEARCH`-based nearest-responder matching with auto-escalation on SLA breach |
| 📡 **Offline-first PWA** | IndexedDB queueing + Background Sync — SOS requests survive a dead connection |
| 🔌 **Real-time alerts** | WebSocket fan-out to responders, live status back to the user |
| 🧾 **Immutable audit log** | Append-only incident event trail — the compliance backbone |
| 📊 **Admin compliance dashboard** | Auto-generated incident reports by type, response time, resolution rate |
| 🏫 **Multi-tenant by design** | Every table is tenant-scoped from day one — one deployment, many campuses |

## 🏗️ Architecture

A modular monolith in Go at launch (small-team-pragmatic, split later — see the design doc's growth-path table), React PWA frontend, Postgres for durable state, Redis for the geo-matching hot path.

```mermaid
flowchart TB
    subgraph Client["Client Layer"]
        PWA["Student/User PWA<br/>(Offline-first, Service Worker cache)"]
        AdminUI["Institute Admin Dashboard<br/>(React)"]
        ResponderApp["Responder PWA<br/>(Warden / Security / Volunteer)"]
    end

    subgraph Edge["Edge"]
        LB["Load Balancer / API Gateway<br/>(Go, JWT auth, rate limiting)"]
    end

    subgraph Services["Application Services (Go) — modular monolith at launch"]
        Auth["Auth & Identity Service<br/>(user + responder verification, JWT)"]
        Dispatch["SOS Dispatch Service<br/>(geo-match orchestration)"]
        Responder["Responder Registry Service<br/>(availability, presence heartbeat)"]
        Notify["Notification / Realtime Gateway<br/>(WebSocket fan-out + push fallback)"]
        Audit["Audit & Compliance Service<br/>(immutable incident logging)"]
        Tenant["Tenant Management Service<br/>(campus onboarding, billing hooks)"]
    end

    subgraph Data["Data Layer"]
        Redis[("Redis<br/>Geospatial index (GEOADD/GEOSEARCH)<br/>+ presence pub/sub")]
        PG[("PostgreSQL<br/>Users, Responders, Incidents, Tenants")]
        S3[("Object Storage<br/>Incident evidence / attachments")]
        Queue[("Event Queue<br/>(durable incident + notification events)")]
    end

    subgraph Obs["Observability"]
        Prom["Prometheus"]
        Graf["Grafana"]
    end

    PWA -->|"HTTPS / WSS"| LB
    AdminUI --> LB
    ResponderApp --> LB

    LB --> Auth
    LB --> Dispatch
    LB --> Notify
    LB --> Audit
    LB --> Tenant

    Dispatch <--> Redis
    Responder <--> Redis
    Dispatch --> Queue
    Notify <--> Queue
    Audit --> PG
    Tenant --> PG
    Auth --> PG
    Audit --> S3

    Services -.metrics.-> Prom --> Graf
```

Two more diagrams — the full SOS request lifecycle and the multi-region scale-out deployment — live in [`docs/`](docs/), alongside the complete [system design write-up](docs/RakshaGrid_System_Design.md) (requirements, data model, API contract, scaling path, and trade-off rationale).

## 🚀 Quick Start

```bash
git clone <this-repo>
cd rakshagrid
docker compose up --build
```

That's it — Postgres (schema auto-applied), Redis, the Go backend on `:8080`, and the React frontend on `:3000` all come up together. Open **http://localhost:3000**.

<details>
<summary>Running backend/frontend separately, without Docker</summary>

```bash
# Backend — requires POSTGRES_DSN and REDIS_ADDR pointing at running instances
cd backend
go mod download
go run ./cmd/server
```

```bash
# Frontend — proxies /v1 to localhost:8080, see vite.config.js
cd frontend
npm install
npm run dev
```

</details>

## 🧪 Testing

```bash
cd backend
go test ./...
```

`internal/dispatch` — the core SOS orchestration logic — is unit-tested against interface fakes, with no live Redis/Postgres required (see `dispatch_test.go`). The rest is exercised via the running stack; adding integration tests against real Postgres/Redis (e.g. via `testcontainers-go`) is a natural next step as the API surface stabilizes.

## 📁 Project Structure

```
backend/
  cmd/server/           entrypoint — wiring, graceful shutdown, escalation sweeper
  internal/models/      shared domain types
  internal/config/      env-driven config
  internal/db/          Postgres + Redis connection setup
  internal/auth/        password hashing, JWT, HTTP middleware
  internal/responder/   Redis geospatial presence registry — the matching engine
  internal/notify/      WebSocket hub — real-time alert fan-out
  internal/audit/       append-only incident log + compliance reports
  internal/dispatch/    core SOS orchestration (unit tested)
  internal/tenant/      campus onboarding
  internal/api/         HTTP routes + handlers — wires every service together
  migrations/           SQL schema
frontend/
  public/sw.js           the offline-first service worker — "works without internet"
                          as working code, not a UI claim
  src/api.js              API client + WebSocket reconnect logic
  src/pages/               LoginForm, SOSButton, ResponderDashboard, AdminDashboard
docs/
  RakshaGrid_System_Design.md   full HLD write-up
  *.mermaid                      architecture diagrams
```

## ☁️ Deployment

**One-command local dev is Docker Compose** (above). For a public URL:

- **Vercel** (recommended — one project, one domain, both services deployed as containers with zero CORS config) — see the [full walkthrough](README_DEPLOY.md#vercel).
- **Railway / Render** (fully separate frontend/backend domains) — see the [full walkthrough](README_DEPLOY.md#railway-or-render).

## 🔧 Reference implementation vs. production-ready

This is real, working, tested code — not pseudocode. A few things are intentionally simplified for an MVP/hackathon stage, each flagged inline in the code where it occurs:

- **Password hashing** — SHA-256 + static pepper; swap for bcrypt/argon2 before real user data.
- **Push notification fallback** — logging stub; wire up FCM/APNs when a mobile shell exists.
- **CORS/WebSocket origin checks** — wide open by default for demo convenience; scope `ALLOWED_ORIGINS` before production.
- **Escalation sweeper** — a polling loop, fine for one instance; see the design doc's growth-path table for when to replace it with a proper job queue.

None of these are hard problems — they're the specific, named list of what separates "MVP for a hackathon + pilot campus" from "handling a real campus's actual emergencies."

## 📄 License

MIT — see [LICENSE](LICENSE).
